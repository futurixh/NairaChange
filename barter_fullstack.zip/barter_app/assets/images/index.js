const pattern = require('./pattern.jpg');

export {pattern};
