import React from 'react';
import {} from 'react-native';
import {Box, Text} from '../theme';

function Settings() {
  return (
    <Box>
      <Text>Settings</Text>
    </Box>
  );
}

export default Settings;
