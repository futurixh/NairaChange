import React from 'react';
import theme, {Box, Text} from '../theme';
import {Container, Content} from 'native-base';

const transactions = [
  {type: 'send', price: -200, to: 'Samuel'},
  {type: 'receive', price: 400, to: 'Samuel'},
  {type: 'receive', price: 400, to: 'Samuel'},
  {type: 'receive', price: 400, to: 'Samuel'},
  {type: 'send', price: -200, to: 'Samuel'},
];

function Notifications() {
  return (
    <Container>
      <Content style={{paddingVertical: theme.spacing.m}}>
        {transactions.map(({type, price, to}, index) => (
          <Box
            key={index}
            paddingHorizontal="l"
            paddingVertical="l"
            style={{marginBottom: 4}}
            borderBottomWidth={1}>
            {type === 'send' ? (
              <Text variant="title2" fontSize={16} lineHeight={20} color="text">
                Your transfer of NGN {price} to {to} has been processed
                successfully
              </Text>
            ) : (
              <Text variant="title2" fontSize={16} lineHeight={20} color="text">
                You received of NGN {price} to {to} has been processed
                successfully
              </Text>
            )}
          </Box>
        ))}
      </Content>
    </Container>
  );
}

export default Notifications;
